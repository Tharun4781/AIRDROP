const http = require("http");
const fs = require("fs");
const path = require("path");
const WebSocket = require("ws");

const port = Number(process.env.PORT) || 3000;
const sessions = new Map();
const server = http.createServer((request, response) => {
  const requested = request.url === "/" ? "/index.html" : request.url;
  const filePath = path.join(__dirname, requested.split("?")[0]);
  if (!filePath.startsWith(__dirname) || !fs.existsSync(filePath)) {
    response.writeHead(404); response.end("Not found"); return;
  }
  const contentType = filePath.endsWith(".html") ? "text/html; charset=utf-8" : "text/plain";
  response.writeHead(200, { "Content-Type": contentType, "Cache-Control": "no-store" });
  fs.createReadStream(filePath).pipe(response);
});
const sockets = new WebSocket.Server({ server });
const send = (socket, payload) => socket.readyState === WebSocket.OPEN && socket.send(JSON.stringify(payload));
const closeSession = (socket) => {
  if (!socket.sessionCode) return;
  const session = sessions.get(socket.sessionCode);
  if (!session) return;
  if (session.sender === socket) session.sender = null;
  if (session.receiver === socket) session.receiver = null;
  const peer = session.sender || session.receiver;
  if (peer) send(peer, { type: "peer-left" });
  if (!session.sender && !session.receiver) sessions.delete(socket.sessionCode);
};
sockets.on("connection", socket => {
  socket.on("message", (data, isBinary) => {
    if (isBinary) {
      const session = sessions.get(socket.sessionCode);
      const peer = session && (session.sender === socket ? session.receiver : session.sender);
      if (peer && peer.readyState === WebSocket.OPEN) peer.send(data, { binary: true });
      return;
    }
    let message;
    try { message = JSON.parse(data.toString()); } catch { send(socket, { type: "error", message: "Invalid message" }); return; }
    if (message.type === "create" || message.type === "join") {
      const session = sessions.get(message.code) || { sender: null, receiver: null };
      const slot = message.type === "create" ? "sender" : "receiver";
      if (session[slot] && session[slot] !== socket) { send(socket, { type: "error", message: "That session is already in use" }); return; }
      session[slot] = socket; sessions.set(message.code, session); socket.sessionCode = message.code; socket.role = slot;
      send(socket, { type: "session-ready", role: slot, code: message.code });
      const peer = slot === "sender" ? session.receiver : session.sender;
      if (peer) { send(socket, { type: "peer-connected" }); send(peer, { type: "peer-connected" }); }
      return;
    }
    const session = sessions.get(socket.sessionCode);
    const peer = session && (session.sender === socket ? session.receiver : session.sender);
    if (peer) send(peer, message);
  });
  socket.on("close", () => closeSession(socket));
  socket.on("error", () => closeSession(socket));
});
server.listen(port, "0.0.0.0", () => console.log(`Lantern running on http://localhost:${port}`));
